<!-- Source: https://www.example.org/Plain -->

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Plain heading page

Body.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)

<!-- Source: https://www.example.org/Products/Broth -->

---
title: "Synthetic Pantry - Broth Concentrate"
meta:
  description: "New meta of /Products/Broth"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Synthetic Pantry - Broth Concentrate

The invented broth concentrate dissolves in hot water; one spoon makes 250 ml.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)

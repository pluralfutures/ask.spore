<!-- Source: https://www.example.org/Products/Gravies -->

---
title: "Synthetic Pantry - Gravies and Au Jus"
meta:
  description: "Synthetic description of /Products/Gravies"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Synthetic Pantry - Gravies and Au Jus

Our invented gravy base is simmered for eight hours from roasted synthetic stock. Each 400 g tub makes 4 litres of gravy.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)

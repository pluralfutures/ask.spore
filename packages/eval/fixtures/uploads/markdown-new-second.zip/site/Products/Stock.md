<!-- Source: https://www.example.org/Products/Stock -->

---
title: "Synthetic Pantry - Stock Cubes"
meta:
  description: "Synthetic description of /Products/Stock"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Synthetic Pantry - Stock Cubes

Invented stock cubes, twelve per box, each for 500 ml of stock.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)

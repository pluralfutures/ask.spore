<!-- Source: https://www.example.org/Recipes/Soup -->

---
title: "Synthetic Pantry - Winter Soup"
meta:
  description: "Synthetic description of /Recipes/Soup"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Synthetic Pantry - Winter Soup

Combine two litres of invented broth with root vegetables and simmer for forty minutes.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)

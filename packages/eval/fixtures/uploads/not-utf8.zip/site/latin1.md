<!-- Source: https://www.example.org/Latin -->

---
title: "Caf�"
meta:
  description: "Synthetic description of /Latin"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Caf�

Body.

� 2026 Synthetic Pantry Co. (invented) � [Buy now](https://www.example.org/shop)

<!-- Source: https://other.example/x -->

---
title: "Away"
meta:
  description: "Synthetic description of /x"
  keywords: "synthetic, pantry, invented"
---

[](https://other.example/)

- [Products](https://other.example/Products)
- [Recipes](https://other.example/Recipes)
- [Contact](https://other.example/Contact)

# Away

Elsewhere.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://other.example/shop)

<!-- Source: https://www.example.org/health/clinic -->

---
title: "Clinic opening hours"
meta:
  description: "Synthetic description of /health/clinic"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# Clinic opening hours

Opening times.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)

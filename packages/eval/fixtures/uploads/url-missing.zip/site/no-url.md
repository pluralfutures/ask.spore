---
title: "No URL"
meta:
  description: "Synthetic description of /x"
  keywords: "synthetic, pantry, invented"
---

[](https://www.example.org/)

- [Products](https://www.example.org/Products)
- [Recipes](https://www.example.org/Recipes)
- [Contact](https://www.example.org/Contact)

# No URL

Body.

© 2026 Synthetic Pantry Co. (invented) · [Buy now](https://www.example.org/shop)
